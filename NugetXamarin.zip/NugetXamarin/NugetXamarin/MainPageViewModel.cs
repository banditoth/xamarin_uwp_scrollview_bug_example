﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NugetXamarin
{
    public class MainPageViewModel
    {
        public DateTime Date
        {
            get
            {
                return new DateTime(1996, 11, 26, 10, 25, 36);
            }
        }
    }
}
